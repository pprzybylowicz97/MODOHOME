# MODOhome Katalog Produktów

Prosty katalog produktów sklepu stacjonarnego MODOhome dla WordPressa. Służy wyłącznie
do prezentacji produktów, zdjęć i cen — **bez WooCommerce, bez koszyka, bez płatności
i bez stanów magazynowych**.

- **Wersja:** 1.4.0
- **Wymaga WordPressa:** 6.1 lub nowszego
- **Wymaga PHP:** 8.1 lub nowszego
- **Licencja:** GPL-2.0-or-later

---

## Co potrafi

- Typ wpisu **Produkty** (`modohome_product`) i hierarchiczna taksonomia
  **Kategorie produktów** (`modohome_product_category`).
- Formularz frontendowy do dodawania produktów **z telefonu** — jedno zdjęcie z aparatu,
  nazwa, cena, gotowe.
- Nowoczesny katalog na stronie: filtry kategorii, wyszukiwarka, sortowanie, numerowane
  strony i okno modalne ze szczegółami.
- Zajawka najnowszych produktów na stronę główną — bez cen, z odnośnikiem do katalogu.
- Osobna rola **Pracownik katalogu** z własnymi uprawnieniami — pracownik widzi
  i edytuje wyłącznie swoje produkty.
- Panel ustawień: kolory, kolumny, proporcje zdjęć, elementy karty, waluta, limity zdjęć.
- **Automatyczna optymalizacja zdjęć**: skalowanie i konwersja do WebP jeszcze przed
  zapisem na dysku — bez osobnej wtyczki i bez usług zewnętrznych.
- Import i eksport CSV oraz log aktywności dla administratora.

---

## Instalacja

1. Spakuj katalog `modohome-katalog-produktow` do pliku ZIP (albo użyj gotowego ZIP-a
   dołączonego do repozytorium).
2. W panelu WordPressa przejdź do **Wtyczki → Dodaj nową → Wyślij wtyczkę na serwer**.
3. Wybierz plik ZIP i kliknij **Zainstaluj teraz**, a następnie **Włącz wtyczkę**.

Podczas aktywacji wtyczka tworzy rolę „Pracownik katalogu”, tabelę logu aktywności
i zapisuje ustawienia domyślne.

### Aktualizacja

Wgraj nowszy ZIP przez ten sam ekran. Produkty, kategorie, zdjęcia i ustawienia zostają
nienaruszone.

### Odinstalowanie

Usunięcie wtyczki **nie kasuje** produktów ani zdjęć. Jeżeli chcesz, żeby dane zniknęły
razem z wtyczką, włącz wcześniej opcję **Ustawienia katalogu → Dane i zaawansowane →
Usuwanie danych**. Zdjęcia zawsze zostają w bibliotece mediów — mogą być używane gdzie indziej.

---

## Pierwsze kroki

1. **Produkty → Kategorie** — dodaj kategorie i podkategorie. Pole „Kolejność”
   decyduje o pozycji na liście filtrów (niższa liczba = wyżej).
2. **Produkty → Ustawienia katalogu** — ustaw walutę, kolory i liczbę kolumn.
3. Utwórz stronę katalogu i wstaw `[modohome_catalog]`.
4. Utwórz stronę dla pracowników i wstaw `[modohome_product_form]`
   oraz `[modohome_my_products]`.
5. **Użytkownicy → Dodaj nowego** — załóż konta z rolą **Pracownik katalogu**.

---

## Shortcode’y

### `[modohome_catalog]` — katalog produktów

| Atrybut | Wartości | Domyślnie | Opis |
|---|---|---|---|
| `category` | slug lub ID kategorii | — | Pokazuje jedną kategorię (z podkategoriami). |
| `categories` | lista po przecinku | — | Pokazuje kilka kategorii. |
| `limit` | liczba | `0` (bez limitu) | Maksymalna liczba produktów do pokazania. |
| `columns` | `1`–`6` | z ustawień | Liczba kolumn na komputerze. |
| `show_filters` | `yes` / `no` | z ustawień | Filtry kategorii i sortowanie. |
| `show_search` | `yes` / `no` | z ustawień | Pole wyszukiwania. |
| `orderby` | `date`, `price_asc`, `price_desc`, `menu_order` | z ustawień | Sortowanie początkowe. |
| `show_sold` | `show` / `hide` | z ustawień | Produkty sprzedane. |
| `heading` | tekst | z ustawień | Nagłówek nad katalogiem. |

Przykłady:

```
[modohome_catalog]
[modohome_catalog category="krzesla"]
[modohome_catalog categories="krzesla,meble,elektronika"]
[modohome_catalog limit="12"]
[modohome_catalog columns="4"]
[modohome_catalog show_filters="yes"]
[modohome_catalog show_search="yes"]
```

### `[modohome_latest]` — zajawka najnowszych produktów

Krótka sekcja na stronę główną. Kafelek różni się od katalogowego: pasek etykiety
na całą szerokość zdjęcia, krótki opis zamiast ceny i odnośnik **„Cena w katalogu →”**
prowadzący na stronę z pełnym katalogiem.

| Atrybut | Wartości | Domyślnie | Opis |
|---|---|---|---|
| `limit` | 1–24 | `4` | Liczba produktów. |
| `columns` | 1–6 | `4` | Kolumny na komputerze (tablet i telefon jak w ustawieniach). |
| `category` | slug lub ID | — | Tylko jedna kategoria. |
| `categories` | lista po przecinku | — | Kilka kategorii. |
| `heading` | tekst | — | Nagłówek nad sekcją. |
| `intro` | tekst | — | Akapit pod nagłówkiem. |
| `link` | adres URL | z ustawień | Cel odnośnika na kafelku. |
| `link_text` | tekst | `Cena w katalogu` | Treść odnośnika. |
| `all_text` | tekst | — | Tekst przycisku pod zajawką; pusty = brak przycisku. |
| `ratio` | jak w ustawieniach | `4:3` | Proporcje zdjęć, też `auto`. |
| `orderby` | `latest`, `price_asc`, `price_desc`, `menu_order` | `latest` | Kolejność. |
| `show_description` | `yes` / `no` | `yes` | Krótki opis pod nazwą. |
| `show_price` | `yes` / `no` | `no` | Cena na kafelku. |
| `show_category` | `yes` / `no` | `yes` | Kategoria nad nazwą. |
| `show_badges` | `yes` / `no` | `yes` | Pasek etykiety. |

Przykłady:

```
[modohome_latest]
[modohome_latest limit="4" heading="Nowe w sklepie"]
[modohome_latest limit="8" columns="4" all_text="Zobacz cały katalog"]
[modohome_latest category="meble" show_price="yes"]
[modohome_latest link="https://twoja-strona.pl/katalog/"]
```

**Ustaw adres katalogu raz:** w **Ustawienia katalogu → Działanie katalogu →
Adres strony katalogu** wpisz pełny adres podstrony z `[modohome_catalog]`.
Zajawka użyje go wtedy automatycznie. Jeśli zostawisz to pole puste, kafelki
zajawki otwierają okno ze szczegółami produktu zamiast prowadzić do katalogu.

Zajawka nie ma filtrów, wyszukiwarki ani stronicowania — to celowo prosta sekcja.
Pełne funkcje daje `[modohome_catalog]`.

### `[modohome_product_form]` — dodawanie produktu z telefonu

Widoczny wyłącznie dla zalogowanych użytkowników z uprawnieniem
`edit_modohome_products`. Zawiera duży przycisk „Dodaj zdjęcie lub zrób zdjęcie”
(korzysta z aparatu telefonu), podgląd zdjęcia, pola nazwy, ceny, ceny poprzedniej,
kategorii, opisu, etykiety i dostępności.

Po zapisaniu — bez przeładowania strony — pojawia się potwierdzenie z miniaturą, nazwą
i ceną oraz przycisk „Dodaj kolejny produkt”.

Atrybut `heading` zmienia nagłówek formularza.

### `[modohome_my_products]` — panel pracownika

Lista własnych produktów w mobilnym układzie. Pracownik może edytować nazwę, cenę, opis
i zdjęcie, zmienić status, oznaczyć produkt jako sprzedany, zduplikować go lub przenieść
do kosza. Atrybut `limit` (domyślnie `20`) ustala liczbę pokazywanych produktów.

---

## Wygląd katalogu

Domyślny układ odpowiada makiecie MODOhome:

- **Zdjęcia pionowe 3:4** — dopasowane do fotografii robionych telefonem na stojąco.
  Przy zdjęciach o bardzo różnych proporcjach wybierz **Dopasuj do zdjęcia** (patrz niżej).
- **Pasek filtrów** u góry: aktywna kategoria na czarnym tle wersalikami, pozostałe
  białe z cienką ramką. Po prawej stronie licznik znalezionych produktów.
- **Cztery kolumny** na komputerze, dwie na tablecie i telefonie.
- **Numerowane strony** (1, 2, 3, …, 8) pod katalogiem — przełączanie bez przeładowania
  strony. Alternatywę „Pokaż więcej” włączysz w ustawieniach.
- **Karta**: kategoria drobnymi wersalikami, nazwa pogrubiona, cena w kolorze akcentu.
- **Ciepłe, jasne tło** katalogu i białe karty.

### Kadrowanie zdjęć

W ustawieniach wyglądu pole **Proporcje zdjęć** ma trzy rodzaje zachowań:

| Ustawienie | Co robi | Kiedy użyć |
|---|---|---|
| **Dopasuj do zdjęcia** | Kafelek przyjmuje proporcje konkretnej fotografii. Nic nie jest przycinane, nie ma pustego tła. Karty w rzędzie mają różną wysokość. | Zdjęcia o mieszanych proporcjach — zrzuty ekranu obok zdjęć z aparatu. |
| Stała proporcja + **Wypełnij kadr** | Równa siatka, ale zdjęcie jest przycinane do kadru. | Zdjęcia robione jednakowo, np. wszystkie pionowe z tego samego ustawienia. |
| Stała proporcja + **Zmieść całe zdjęcie** | Równa siatka, całe zdjęcie widoczne, ale wokół zostaje puste tło. | Gdy zależy Ci na równej siatce i nie przeszkadzają puste pasy. |

Zmierzone na zrzucie ekranu telefonu (450×975) w kafelku 3:4:

| Tryb | Widać ze zdjęcia | Puste tło w kafelku |
|---|---|---|
| Wypełnij kadr | 62% | 0% |
| Zmieść całe zdjęcie | 100% | 39% |
| **Dopasuj do zdjęcia** | **100%** | **0%** |

Okno modalne zawsze pokazuje całe zdjęcie w jego naturalnych proporcjach, tak duże,
jak zmieści się na ekranie — niezależnie od ustawienia kafelków.

### Kolory etykiet

Każda etykieta ma własny kolor, dobrany do znaczenia:

| Etykieta | Kolor |
|---|---|
| Nowość, Promocja | czerwony (kolor akcentu) |
| Ostatnia sztuka | żółty z czarnym tekstem |
| Bestseller, Dostępny od ręki, Ekspozycja | czarny |
| Dodano dzisiaj | czarny |

Kolor akcentu, tła, kart i tekstu zmienisz w ustawieniach. Żółty dla „Ostatniej sztuki”
nadpiszesz własnym CSS-em:

```css
.modohome-catalog-badge--last { background: #ff9900; }
```

---

## Dane produktu

| Pole | Wymagane | Gdzie |
|---|---|---|
| Nazwa | tak | Tytuł wpisu |
| Zdjęcie główne | tak | Obrazek wyróżniający |
| Galeria dodatkowa | nie | Panel „Galeria zdjęć” |
| Cena | tak | Panel „Dane produktu” |
| Cena poprzednia | nie | Panel „Dane produktu” |
| Krótki opis | nie | Panel „Dane produktu” |
| Kategoria | tak | Panel „Kategorie produktów” |
| Etykieta | nie | Nowość, Promocja, Ostatnia sztuka, Bestseller, Dostępny od ręki, Ekspozycja |
| Dostępność | tak | Dostępny, Zarezerwowany, Sprzedany, Ukryty |
| Data dodania | automatycznie | Data wpisu |
| Autor | automatycznie | Autor wpisu |
| Kolejność | nie | Panel „Atrybuty” → Kolejność |

Cena zapisywana jest jako liczba, a wyświetlana z walutą z ustawień (domyślnie `zł`).
Produkty ze statusem **Ukryty** nigdy nie pojawiają się w katalogu publicznym.

---

## Uprawnienia

Rola **Pracownik katalogu** (`modohome_catalog_worker`) **może**: zalogować się, korzystać
z formularza frontendowego, dodawać produkty, przesyłać zdjęcia, edytować i usuwać
**wyłącznie własne** produkty oraz zmieniać ich status.

**Nie może**: edytować stron i wpisów, instalować wtyczek, zmieniać ustawień WordPressa,
zarządzać użytkownikami, dotykać produktów innych pracowników ani — domyślnie — tworzyć
nowych kategorii.

Wtyczka używa własnych uprawnień, nie standardowej roli autora:

```
edit_modohome_products, edit_others_modohome_products, publish_modohome_products,
delete_modohome_products, delete_others_modohome_products, edit_published_modohome_products,
delete_published_modohome_products, read_private_modohome_products, …
manage_modohome_catalog          — ustawienia, import/eksport, log
assign_modohome_product_categories — przypisywanie kategorii
manage_modohome_product_categories — tworzenie kategorii (opcjonalne dla pracowników)
```

Administrator ma pełną kontrolę. Redaktor zarządza wszystkimi produktami, ale nie ma
dostępu do ustawień wtyczki.

Dwa ustawienia sterują pracą zespołu:

- **Publikacja produktów pracowników** — włączona (domyślnie) publikuje od razu; wyłączona
  kieruje produkty do zatwierdzenia (status „Oczekujące”).
- **Kategorie przez pracowników** — pozwala pracownikom tworzyć nowe kategorie.

---

## Lista produktów w panelu

Kolumny: miniatura, nazwa, cena, cena poprzednia, kategoria, etykieta, dostępność, autor,
data dodania.

Dostępne są: filtrowanie po kategorii, dostępności i autorze, wyszukiwanie po nazwie,
sortowanie po cenie i dacie, akcje wierszowe **Oznacz jako sprzedany** i **Duplikuj produkt**,
a także akcje zbiorcze: zmiana dostępności i duplikowanie. Zbiorcze przypisanie kategorii
zrobisz przez **Edycja grupowa** WordPressa.

---

## Ustawienia katalogu

**Produkty → Ustawienia katalogu**, cztery sekcje:

- **Wygląd** — kolor główny, tekstu, tła, kart i etykiet; liczba kolumn na komputerze,
  tablecie i telefonie; proporcje zdjęć; sposób przycinania; minimalna wysokość kart;
  promień zaokrąglenia; odstępy; cień kart; nagłówek i tekst nad katalogiem.
- **Elementy karty** — kategoria, opis, cena poprzednia, etykiety, status dostępności,
  data dodania, „Zobacz szczegóły”, oznaczenie „Dodano dzisiaj”.
- **Działanie katalogu** — produkty na stronę, domyślne sortowanie, produkty sprzedane,
  tryb szczegółów (modal / podstrona / brak), podstrony produktów, wyszukiwarka, filtry,
  sposób stronicowania, licznik produktów, publikacja bez zatwierdzania, kategorie dla
  pracowników, automatyczne ukrycie po X dniach, waluta i jej pozycja.
- **Optymalizacja zdjęć** — patrz sekcja poniżej.

Ustawienie **„Przycisk «Pokaż więcej»”** decyduje o stronicowaniu: wyłączone (domyślnie)
daje numerowane strony jak w makiecie, włączone — przycisk doładowujący kolejne produkty.
Oba tryby działają bez przeładowania strony.
- **Dane i zaawansowane** — log aktywności, usuwanie danych przy deinstalacji, własny CSS.

Przycisk **Przywróć ustawienia domyślne** kasuje wszystkie zmiany (z potwierdzeniem).

Pole **Własny CSS** zapisuje wyłącznie administrator; treść jest sanityzowana i ładowana
tylko tam, gdzie działa katalog.

---

## Zdjęcia i ich optymalizacja

- Dozwolone formaty wejściowe: **JPG, PNG, WebP**; typ sprawdzany po zawartości pliku,
  nie po nazwie.
- Zdjęcie jest **skalowane i konwertowane do WebP zanim WordPress zapisze je na dysku**.
  Dzięki temu w bibliotece mediów nie ląduje wielomegabajtowy oryginał z telefonu.
- Miniatury generuje WordPress — ponieważ plik źródłowy jest już w WebP, wszystkie
  rozmiary pochodne też są w WebP.
- Orientacja zdjęć z telefonu jest korygowana na podstawie danych EXIF.
- Pliki trafiają wyłącznie do **biblioteki mediów** — wtyczka niczego nie zapisuje we
  własnym katalogu.
- Zbyt duży lub nieprawidłowy plik kończy się czytelnym komunikatem, bez tworzenia
  pustego produktu.

### Dlaczego optymalizacja dzieje się przed zapisem

Gdyby skalowanie zostawić WordPressowi (mechanizm „big image”), oryginał **zostaje na
dysku obok** wersji przeskalowanej — zdjęcie 8 MB zajmuje wtedy 8 MB plus wszystkie
rozmiary pochodne. Wtyczka przetwarza plik tymczasowy jeszcze przed przeniesieniem go
do katalogu uploadów, więc na serwerze zostaje wyłącznie mała wersja.

Zmierzone na zdjęciu testowym 4000×3000: **2,7 MB → 0,2 MB** (8% oryginału),
proporcje zachowane, dłuższy bok przycięty do 1600 px.

### Ustawienia optymalizacji

**Produkty → Ustawienia katalogu → Optymalizacja zdjęć**:

| Ustawienie | Domyślnie | Opis |
|---|---|---|
| Maksymalny rozmiar przesyłanego pliku | 10 MB | Limit dla osoby wysyłającej; nigdy nie przekroczy limitu serwera. |
| Maksymalny wymiar obrazu | 1600 px | Dłuższy bok po przeskalowaniu. |
| Konwersja do WebP | włączona | Zapis w WebP zamiast JPG/PNG. |
| Jakość WebP | 82 | Zakres 40–100. Poniżej 70 widać artefakty, powyżej 90 pliki rosną bez zysku. |
| Optymalizuj całą stronę | wyłączona | Rozszerza skalowanie i konwersję na **wszystkie** zdjęcia wysyłane do WordPressa, nie tylko produktowe. |

Strona ustawień pokazuje, czy serwer w ogóle obsługuje zapis WebP (wymaga GD z WebP
albo rozszerzenia Imagick). Jeśli nie obsługuje, konwersja jest **po cichu pomijana** —
zdjęcia są wtedy tylko skalowane, nic się nie psuje.

Zabezpieczenie: jeżeli plik WebP wyszedłby większy od oryginału, a zdjęcia nie trzeba
było skalować, wtyczka zostawia oryginał.

### Czy potrzebuję osobnej wtyczki do optymalizacji?

Do samego katalogu — **nie**. Zdjęcia produktowe przechodzą przez jeden formularz
i są optymalizowane u źródła.

Osobna wtyczka ma sens, gdy chcesz dodatkowo: przerobić **zdjęcia już wgrane** wcześniej,
serwować WebP z zachowaniem kopii JPG dla starych przeglądarek, albo optymalizować
obrazy z motywu i innych wtyczek. Wtedy włącz opcję **Optymalizuj całą stronę** —
w wielu przypadkach zastąpi to osobną wtyczkę.

### Zdjęcia wgrane wcześniej

Optymalizacja działa na **nowych** plikach. Zdjęcia wgrane przed włączeniem opcji
zostają w dotychczasowym formacie. Żeby je przerobić, wgraj je ponownie albo użyj
wtyczki do masowej konwersji — wtyczka katalogu nie rusza plików, które już są na dysku.

---

## Import i eksport CSV

**Produkty → Import i eksport**. Plik w UTF-8, separator **średnik**, kolumny:

```
nazwa; opis; cena; cena_poprzednia; kategoria; status; etykieta; autor; data; zdjecie
```

Wymagane przy imporcie: `nazwa`, `cena`, `kategoria`. Kilka kategorii rozdziel znakiem `|`.
Nieistniejące kategorie zostaną utworzone. Kolumna `zdjecie` przyjmuje adres URL obrazka
**już obecnego w bibliotece mediów**.

Produkty o nazwie już istniejącej w katalogu są domyślnie pomijane, a ich liczba pokazana
w podsumowaniu. Zaznacz „Dodaj mimo istniejącego produktu o tej samej nazwie”, żeby to wyłączyć.

---

## Log aktywności

**Produkty → Log aktywności** (tylko administrator). Zapisuje: kto dodał produkt, kto zmienił
cenę, kto zmienił status i kiedy produkt został usunięty. Nie przechowuje adresów IP ani
innych danych osobowych — tylko identyfikator użytkownika, produkt i rodzaj zdarzenia.
Log można wyłączyć w ustawieniach i wyczyścić jednym przyciskiem.

---

## Struktura plików

```
modohome-katalog-produktow/
├── modohome-katalog-produktow.php   Plik główny, autoloader, stałe
├── uninstall.php                    Deinstalacja (usuwa dane tylko na życzenie)
├── README.md
├── includes/
│   ├── class-plugin.php             Spina moduły, ładuje szablony
│   ├── class-activator.php          Aktywacja: role, tabela logu, cron
│   ├── class-settings.php           Ustawienia i sanityzacja
│   ├── class-roles.php              Rola pracownika i uprawnienia
│   ├── class-post-type.php          Typ wpisu Produkty
│   ├── class-taxonomy.php           Kategorie produktów
│   ├── class-product.php            Pola produktu, formatowanie
│   ├── class-product-actions.php    Status, kosz, duplikat, zmiana ceny
│   ├── class-query.php              Zapytania katalogu
│   ├── class-image-handler.php      Przesyłanie i walidacja zdjęć
│   ├── class-image-optimizer.php    Skalowanie i konwersja do WebP
│   ├── class-activity-log.php       Log aktywności
│   ├── class-shortcodes.php         Rejestracja shortcode’ów
│   ├── class-ajax.php               Punkty końcowe AJAX
│   ├── class-assets.php             Warunkowe ładowanie CSS/JS
│   └── class-cron.php               Automatyczne ukrywanie produktów
├── admin/
│   ├── class-admin.php              Spina ekrany panelu
│   ├── class-metaboxes.php          Panel danych produktu i galeria
│   ├── class-columns.php            Kolumny, filtry, akcje listy
│   ├── class-settings-page.php      Ustawienia katalogu
│   ├── class-tools-page.php         Import i eksport CSV
│   └── class-log-page.php           Log aktywności
├── public/
│   ├── class-catalog.php            Renderowanie katalogu
│   ├── class-product-form.php       Formularz dodawania
│   ├── class-my-products.php        Panel pracownika
│   └── class-latest.php             Zajawka najnowszych produktów
├── templates/                       Szablony do nadpisania w motywie
│   ├── catalog.php
│   ├── product-card.php
│   ├── product-modal.php
│   ├── product-form.php
│   ├── my-products.php
│   ├── latest.php
│   └── latest-card.php
├── assets/
│   ├── css/  catalog.css · form.css · admin.css
│   └── js/   catalog.js · form.js · admin.js
└── languages/
    └── modohome-katalog-produktow.pot
```

### Nadpisywanie szablonów w motywie

Skopiuj wybrany plik z `templates/` do katalogu motywu:

```
twoj-motyw/modohome-katalog-produktow/product-card.php
```

Wtyczka użyje wersji z motywu, więc aktualizacja nie nadpisze Twoich zmian.

---

## Bezpieczeństwo

- Nonce w każdym formularzu i każdym żądaniu AJAX.
- Sprawdzanie uprawnień przed **każdą** operacją zapisu — także po stronie serwera,
  niezależnie od tego, co pokazuje interfejs.
- Sanityzacja danych wejściowych i escaping przy wyświetlaniu.
- Ograniczone typy plików, weryfikacja rozmiaru i faktycznej zawartości obrazka.
- Brak możliwości dodania produktu bez zalogowania.
- Pracownik nie edytuje cudzych produktów — blokada zarówno w `map_meta_cap`,
  jak i w każdym punkcie końcowym.
- Brak bezpośredniego dostępu do plików PHP (`ABSPATH`, pliki `index.php`).
- Wszystkie funkcje, klasy, opcje i hooki mają prefiks `modohome_catalog_`;
  kod korzysta z przestrzeni nazw `MODOhome\Catalog`.
- Klasy CSS mają prefiks `modohome-catalog-`, więc nie nadpisują stylów motywu.

---

## Wydajność

- CSS i JavaScript ładują się **tylko** na podstronach z shortcode’em wtyczki
  i na ekranach wtyczki w panelu.
- Front działa bez jQuery — czysty JavaScript.
- Liczniki produktów w kategoriach są cache’owane na 5 minut.
- Zdjęcia są zmniejszane i konwertowane do WebP przed zapisem, więc katalog uploadów
  nie puchnie od zdjęć z telefonu.
- Wtyczka nie wymaga WooCommerce ani żadnego zewnętrznego frameworka.

---

## Rozwiązywanie problemów

**Katalog jest pusty, choć produkty istnieją.** Sprawdź, czy produkty są opublikowane
i czy nie mają statusu „Ukryty”. Jeśli filtr wskazuje kategorię, upewnij się, że slug
w shortcode’zie jest poprawny.

**Formularz pokazuje „Twoje konto nie ma uprawnień”.** Użytkownik musi mieć rolę
„Pracownik katalogu” (albo wyższą) — rola nadaje `edit_modohome_products` i `upload_files`.

**Zdjęcie z telefonu nie przechodzi.** Zwiększ „Maksymalny rozmiar zdjęcia” w ustawieniach.
Limit i tak nie przekroczy limitu serwera (`upload_max_filesize`).

**Produkty pracowników nie pojawiają się w katalogu.** Sprawdź ustawienie „Publikacja
produktów pracowników” — przy wyłączonym czekają na zatwierdzenie w **Produkty → Wszystkie**
ze statusem „Oczekujące”.

**Nazwy produktów są ucinane albo kafelki wychodzą poza siatkę (naprawione w 1.3.1).**
Kafelkom brakowało `min-width: 0`, więc długa nazwa rozpychała kartę zamiast się zawinąć.
Od 1.3.1 nazwa zawsze się zawija, także gdy motyw narzuca nagłówkom wersaliki lub
większą czcionkę — reguły wtyczki mają wyższą specyficzność niż typowe `.entry-content h3`.

Skutek uboczny: wtyczka wymusza teraz normalną wielkość liter w nazwach produktów,
zgodnie z projektem katalogu. Jeśli wolisz wersaliki, dodaj we własnym CSS:

```css
.modohome-catalog .modohome-catalog-card-title { text-transform: uppercase; }
```

**Zdjęcia są przycięte w katalogu.** Ustaw **Proporcje zdjęć** na „Dopasuj do zdjęcia —
bez przycinania”. Stały kadr zawsze przytnie zdjęcie o innych proporcjach; alternatywa
„Zmieść całe zdjęcie” pokaże całość, ale zostawi puste tło wokół.

**Ustawienia wyglądu nie działają (dotyczy wersji do 1.2.0 włącznie).**
Zmienne CSS były deklarowane na kontenerze katalogu zamiast na `:root`, przez co
przesłaniały wartości z panelu ustawień — nie działały kolumny na telefonie i tablecie,
kolory, odstępy ani proporcje zdjęć. Naprawione w 1.2.1; zaktualizuj wtyczkę.

**Katalog wygląda inaczej niż na makiecie po aktualizacji.** Nowe wartości domyślne
działają tylko na świeżych instalacjach — wcześniejsze ustawienia zostają nietknięte.
Kliknij **Przywróć ustawienia domyślne** albo ustaw ręcznie: proporcje 3:4, tło `#f4f2ee`,
zaokrąglenie 2 px, „Pokaż więcej” wyłączone, „Zobacz szczegóły” wyłączone.

**Zdjęcia nie zapisują się w WebP.** Sprawdź wiersz „Obsługa WebP na serwerze”
w ustawieniach. Jeśli pokazuje „Niedostępna”, hosting musi włączyć GD z obsługą WebP
albo rozszerzenie Imagick. Do tego czasu zdjęcia są tylko skalowane.

**Zmiana ustawienia podstron produktu nic nie dała.** Wejdź w **Ustawienia → Bezpośrednie
odnośniki** i zapisz, żeby odświeżyć reguły przepisywania.
